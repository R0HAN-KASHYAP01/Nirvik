class AppUser {
  final String id;
  final String name;
  final String email;
  final UserRole role;
  final String status;
  final String? department;
  final String? designation;
  final String? registrationNumber;
  final String? organizationId;
  final String? district;   // NEW — from district_administrators.district
  final String? state;      // NEW — from district_administrators.state

  const AppUser({
    required this.id,
    required this.name,
    required this.email,
    required this.role,
    required this.status,
    this.department,
    this.designation,
    this.registrationNumber,
    this.organizationId,
    this.district,
    this.state,
  });
}